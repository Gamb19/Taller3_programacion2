/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio24 {
    public static void main(String[] args){
        int horas = 0;
        int minutos = 0;
        int segundos = 0;

        while (true) {
            try {
              
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            segundos++;
            if (segundos >= 60) {
                segundos = 0;
                minutos++;
            }
            if (minutos >= 60) {
                minutos = 0;
                horas++;
            }
            System.out.printf("%02d:%02d:%02d\n", horas, minutos, segundos);
       
        }
    }
}
