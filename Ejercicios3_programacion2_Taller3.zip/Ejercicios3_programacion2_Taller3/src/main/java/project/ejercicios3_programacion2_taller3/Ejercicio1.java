/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio1 {
    public static void main(String[] args){
     Scanner sc = new Scanner (System.in);
    float num1,num2;
    System.out.println("Numero 1:");
    num1= sc.nextFloat(); 
    System.out.println("Numero 1:");
    num2= sc.nextFloat();
    
    if(num1>num2){
     System.out.println("El num1 es mayor");   
    } else if(num1==num2){
        System.out.println("Son iguales");  
    }else{
        System.out.println("El num 2 es mayor");   
    }
            
    
    }


}
