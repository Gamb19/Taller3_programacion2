/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio14 {
    public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      int dia;
      System.out.println("Numero del dia que quiere saber :");
      dia=sc.nextInt();
      switch(dia){
          case 1 -> System.out.println("Lunes");
          case 2 -> System.out.println("Martes");
          case 3 -> System.out.println("Miercoles");
          case 4 -> System.out.println("Jueves");
          case 5 -> System.out.println("Viernes"); 
          case 6 -> System.out.println("Sabado");
          case 7 -> System.out.println("Domingo");
      }
    }
}
