/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio8 {
    public static void main(String[] args){
        Scanner sc = new Scanner (System.in);
        float lado1,lado2,lado3;
       System.out.println("Lado 1: ");
       lado1= sc.nextFloat();
       System.out.println("Lado 2: ");
       lado2= sc.nextFloat();
       System.out.println("Lado 3: ");
       lado3= sc.nextFloat();
       
       if(lado1==lado2 && lado1==lado3 && lado2==lado3){
           System.out.print("Es equilatero");
       }else if(lado1==lado2 && lado1!=lado3){
           System.out.println("Es isoceles");
       }else if(lado1==lado3 && lado2!=lado1){
           System.out.println("Es isoceles");
       }else if(lado2==lado3 && lado1!=lado2){
            System.out.println("Es isoceles");
       }else if(lado2!=3 && lado1!=lado2 && lado1!= lado3){
           System.out.println("Es escaleno");
       }
       
    }
}
