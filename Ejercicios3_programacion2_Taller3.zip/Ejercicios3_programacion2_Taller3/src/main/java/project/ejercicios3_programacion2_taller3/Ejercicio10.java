/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("Cuanto te costo el producto: ");
        float precio = sc.nextFloat();
        sc.nextLine();

        System.out.println("De que tamannio es 1 o 2: ");
        int tamannio= sc.nextInt();
        sc.nextLine();

        System.out.println("De que tipo es el producto A o B: ");
        String tipo = sc.nextLine();
        
        if(tipo.contains("A")){
            if (tamannio==1) {
                precio=(float) (precio+0.20);
            }else if(tamannio==2){
                 precio=(float) (precio+0.30);
            }
             System.out.println("El total por tipo: "+tipo+" y tamannio "+tamannio+"es: "+ precio);
        }
          if(tipo.contains("B")){
            if (tamannio==1) {
                precio=(float) (precio-0.30);
            }else if(tamannio==2){
                 precio=(float) (precio-0.50);
            }
            System.out.println("El total por tipo: "+tipo+"y tamannio"+tamannio+"es: "+ precio);
        }     
        
    }
}
