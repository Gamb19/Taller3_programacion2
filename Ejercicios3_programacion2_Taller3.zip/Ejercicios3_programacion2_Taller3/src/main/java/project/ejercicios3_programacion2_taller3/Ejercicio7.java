/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio7 {
     public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
        
        // Pedir las coordenadas y radios de los dos círculos
        System.out.println("coordenadas (x1, y1) y el radio del primer círculo:");
        double x1 = sc.nextDouble();
        double y1 = sc.nextDouble();
        double r1 = sc.nextDouble();
        
        System.out.println("coordenadas (x2, y2) y el radio del segundo círculo:");
        double x2 = sc.nextDouble();
        double y2 = sc.nextDouble();
        double r2 = sc.nextDouble();
        
        // Calcular la distancia entre los centros de los círculos
        double distancia = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
        
        // Clasificar los círculos según su relación
        if (distancia > r1 + r2) {
            System.out.println("son exteriores.");
        } else if (distancia == r1 + r2) {
            System.out.println(" son tangentes exteriores.");
        } else if (distancia < Math.abs(r1 - r2)) {
            System.out.println("son interiores.");
        } else if (distancia == Math.abs(r1 - r2)) {
            System.out.println("son tangentes interiores.");
        } else if (distancia < r1 + r2) {
            System.out.println("son secantes.");
        } else if (x1 == x2 && y1 == y2 && r1 == r2) {
            System.out.println("son concéntricos.");
        }
    }
}
  
