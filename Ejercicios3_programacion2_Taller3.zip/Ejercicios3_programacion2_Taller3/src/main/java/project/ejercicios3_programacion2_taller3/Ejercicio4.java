/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio4 {
    public static void main(String[] args){
       Scanner sc = new Scanner(System.in);
       System.out.println("Ingresa la palabra");
       String palabra = sc.nextLine();
        
        boolean contieneMayuscula = false;
        for (int i = 0; i < palabra.length(); i++) {
            if (Character.isUpperCase(palabra.charAt(i))) {
                contieneMayuscula = true;
                break;
            }
        }
          if (contieneMayuscula) {
            System.out.println("La palabra tiene una letra mayúscula.");
        } else {
            System.out.println("La palabra NO tiene letra mayúscula.");
        }
    }
}
