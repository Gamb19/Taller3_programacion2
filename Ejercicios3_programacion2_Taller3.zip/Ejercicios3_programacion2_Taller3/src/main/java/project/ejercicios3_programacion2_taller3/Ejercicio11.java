/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio11 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n_alumnos,costo=0;
        System.out.println("Cuantos alumnos son: ");
        n_alumnos= sc.nextInt();
        
        if(n_alumnos >=100){
            costo=costo+65;
          System.out.println("Cada alumno debe pagar: "+ costo);
        }else if(n_alumnos <99 && n_alumnos>=50){
            costo=costo+70;
             System.out.println("Cada alumno debe pagar: "+ costo);
        }
        else if(n_alumnos <49 && n_alumnos>=30){
            costo=costo+70;
             System.out.println("Cada alumno debe pagar: "+ costo);
        }
        else if(n_alumnos<30){
            costo=costo+4000;
            costo=costo/n_alumnos;
            System.out.println("Cada alumno debe pagar: "+ costo);
            
        }
        
    }
}
