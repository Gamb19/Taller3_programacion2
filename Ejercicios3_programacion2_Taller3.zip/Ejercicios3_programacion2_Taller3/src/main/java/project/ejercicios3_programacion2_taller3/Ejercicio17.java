/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio17 {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
    int num = (int)Math.floor(Math.random()*100+1); 
    int adivinar;
    for(int i=0; i<10;i++){
       
        System.out.println("Intento numero: "+(i+1));
        System.out.println("Digite el numero: ");
        adivinar= sc.nextInt();
        if(adivinar==num){
            System.out.println("Adivinado");
            break;
        }else{
            System.out.println("No es");
        }
        if(i==10){
            System.out.println("Numero de intentos maximo, no lo adivinaste");
            break;
        }
    }
        
    }
}
