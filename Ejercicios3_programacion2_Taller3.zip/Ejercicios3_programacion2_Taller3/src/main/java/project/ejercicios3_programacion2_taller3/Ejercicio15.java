/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio15 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
      int mes;
      System.out.println("Numero del dia que quiere saber :");
       mes=sc.nextInt();
      switch(mes){
          case 1 -> System.out.println("Enero: 31 dias");
          case 2 -> System.out.println("Febrero: 28 dias");
          case 3 -> System.out.println("Marzo: 31 dias");
          case 4 -> System.out.println("Abril: 30 dias");
          case 5 -> System.out.println("Mayo: 31 dias"); 
          case 6 -> System.out.println("Junio: 30 dias");
          case 7 -> System.out.println("Julio: 31 dias");
          case 8 -> System.out.println("Agosto: 31 dias");
          case 9 -> System.out.println("Septiembre: 30 dias");
          case 10 -> System.out.println("Ocubre: 31 dias");
          case 11 -> System.out.println("Noviembre: 30 dias");
          case 12 -> System.out.println("Diciembre: 31 dias");
      }
    }
}
