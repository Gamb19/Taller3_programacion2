/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio23 {
    public static void main(String[] args){
           Scanner scanner = new Scanner(System.in);
        double pagoInicial, totalPagado = 0;
        int meses;

        
        System.out.print("pago inicial: ");
        pagoInicial = scanner.nextDouble();

        System.out.print("meses: ");
        meses = scanner.nextInt();

     
        double pagoMensual = (Math.pow(2, meses - 1) * pagoInicial) / ((Math.pow(2, meses) - 1));
        System.out.printf("El pago mensual:: ", pagoMensual);

     
        for (int i = 1; i <= meses; i++) {
            totalPagado += pagoMensual * Math.pow(2, i - 2);
        }

        System.out.printf("El total pagado después de: ", meses, totalPagado);
    }
           
}
