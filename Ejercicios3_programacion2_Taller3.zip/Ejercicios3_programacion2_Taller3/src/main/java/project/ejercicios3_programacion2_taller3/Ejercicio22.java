/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio22 {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int total=1;
        System.out.println("Numero base: ");
        int base= sc.nextInt();
        System.out.println("Exponente");
        int exponente= sc.nextInt();
        
        for(int i=1; i<=exponente;i++){
            total*=base;
        }
        System.out.println("Total: "+ total);
    }
}
