/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio13 {
    public static void main(String[] args){
    Scanner sc = new Scanner(System.in); 
    int lado;
    System.out.println("Que resultado obtuvo: ");
    lado= sc.nextInt();
        switch (lado) {
            case 1 -> System.out.println("El lado opuesto es seis");
            case 2 -> System.out.println("El lado opuesto es cinco");
            case 3 -> System.out.println("El lado opuesto es cuatro");
            case 4 -> System.out.println("El lado opuesto es tres");
            case 5 -> System.out.println("El lado opuesto es dos");
            case 6 -> System.out.println("El lado opuesto es uno");
            default -> System.out.println("El numero no es valido");
        }
    }
}
