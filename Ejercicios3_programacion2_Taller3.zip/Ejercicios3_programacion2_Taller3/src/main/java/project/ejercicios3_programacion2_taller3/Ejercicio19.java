/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;

/**
 *
 * @author molin
 */
public class Ejercicio19 {
    public static void main(String args[]){
           Scanner sc = new Scanner(System.in);
        char letra;
        boolean validar = true;

        do {
            System.out.print("Introduce un caracter (si escribes un espacio sales): ");
            letra = sc.next().charAt(0);

            if (String.valueOf(letra).trim().equals("")){
                validar = false;
                break;
            }
            if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
                System.out.println("Es vocal");
            } else {
                System.out.println("No es vocal");
            }
        } while (validar);

       
    }
        
        
    }

