/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio30 {
   public static void main(String[] args){
        Random NumeroRandom = new Random();
        int[][] numeros = new int[4][5];
        int[] sumasFilas = new int[4];
        int[] sumasColumnas = new int[5];
        int sumaTotal = 0;
        
        
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros[i].length; j++) {
                numeros[i][j] = NumeroRandom.nextInt(900) + 100; 
                sumasFilas[i] += numeros[i][j];
                sumasColumnas[j] += numeros[i][j];
            }
            sumaTotal += sumasFilas[i];
        }
        
       
        for (int j = 0; j < sumasColumnas.length; j++) {
            sumaTotal += sumasColumnas[j];
        }
        
     
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros[i].length; j++) {
                System.out.print(numeros[i][j] + "\t");
            }
            System.out.println("| " + sumasFilas[i]);
        }
        
        for (int j = 0; j < sumasColumnas.length; j++) {
            System.out.print("--\t");
        }
        System.out.println("|");
        for (int j = 0; j < sumasColumnas.length; j++) {
            System.out.print(sumasColumnas[j] + "\t");
        }
        System.out.println("| " + sumaTotal);
   } 
}
