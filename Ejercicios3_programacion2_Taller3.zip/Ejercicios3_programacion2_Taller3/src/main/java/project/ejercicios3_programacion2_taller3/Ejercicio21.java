/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio21 {
   public static void main(String[] args){
       Scanner sc = new Scanner(System.in);
       float num1, num2,suma,total = 0,intervalo = 0,fueraInt = 0;
       boolean validacion=true;
       do{
           System.out.println("Limite inferior: ");
           num1= sc.nextFloat();
           
           System.out.println("Limite superior:");
           num2=sc.nextFloat();
           
           if(num1>=num2){
               System.out.println("El limite inferior debe ser menor al Limite superior");
               validacion=true;
           }else{
               validacion=false;
           }
        
       }while(validacion);
       
       do{
         System.out.println("Introduce un numero, si digitas el 0 se acaba el proceso");
         suma=sc.nextFloat();
         if(suma==0){
             break;
         }
         if(suma > num1 && suma < num2){
             intervalo=intervalo+1;
             total=total+suma;
             
         }else if(suma==num1 || suma==num2){
             System.out.println("Introduciste un numero igual a uno de los limites");
         }
         else{
             fueraInt++;
         }
         
         
       }while(true);
       System.out.println("Suma dentro del intervalo: "+total);
       System.out.println("Total numeros fuera del intervalo: "+fueraInt);
       System.out.println("Total numeros dentro del Intervalo: "+intervalo);
       
   } 
}
