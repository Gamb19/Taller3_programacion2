/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio16 {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        float peso,total=0;
        System.out.println("Peso de la caja: ");
        peso= sc.nextFloat();
        System.out.println("Destino:\n 1 america del norte \n 2 America central \n 3 America del sur \n 4 Europa \n 5 Asia");
        int destino= sc.nextInt();
        
        if(peso>5){
            System.out.println("No es admitido el paquete, sobre pasa el peso");
        }else{
            switch(destino){
                case 1 -> total= peso*24;
                case 2 -> total= peso*20;
                case 3 -> total= peso*21;
                case 4 -> total= peso*10;
                case 5 -> total = peso*18;
            }
          System.out.println("Debe pagar: "+total);
        }
        
     
    }
}
