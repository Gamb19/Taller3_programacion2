/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio28 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);
         int[] numeros = new int[10];
        int maximo = 0;
        int minimo = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("Ingrese un número: ");
            numeros[i] = entrada.nextInt();
        }
        maximo = numeros[0];
        minimo = numeros[0];
        for (int i = 1; i < 10; i++) {
            if (numeros[i] > maximo) {
                maximo = numeros[i];
            }
            if (numeros[i] < minimo) {
                minimo = numeros[i];
            }
        }
        System.out.println("Los números ingresados son: ");
        for (int i = 0; i < 10; i++) {
            System.out.print(numeros[i] + " ");
            if (numeros[i] == maximo) {
                System.out.print("(máximo) ");
            }
            if (numeros[i] == minimo) {
                System.out.print("(mínimo) ");
            }
        }
    }
}
