/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio27 {
    public static void main(String[] args){
         Scanner entrada = new Scanner(System.in);

        int[] numeros = new int[10];
        for (int i = 0; i < 10; i++) {
            System.out.print("Ingrese un número: ");
            numeros[i] = entrada.nextInt();
        } 
        System.out.println("Inverso:");
        for (int i = 9; i >= 0; i--) {
            System.out.println(numeros[i]);
        }
    }
}
