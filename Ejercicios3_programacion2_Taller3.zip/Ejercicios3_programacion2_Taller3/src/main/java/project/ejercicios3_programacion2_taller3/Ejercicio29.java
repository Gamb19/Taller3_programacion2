/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio29 {
    public static void main(String[] args){
       Scanner sc = new Scanner(System.in);
        int[][] numeros = new int[4][5];
        int[] sumasFilas = new int[4];
        int[] sumasColumnas = new int[5];
        int sumaTotal = 0;
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros[i].length; j++) {
                System.out.print("Introduce el número en la fila " + (i+1) + " columna " + (j+1) + ": ");
                numeros[i][j] = sc.nextInt();
                sumasFilas[i] += numeros[i][j];
                sumasColumnas[j] += numeros[i][j];
                sumaTotal += numeros[i][j];
            }
        }
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros[i].length; j++) {
                System.out.print(numeros[i][j] + "\t");
            }
            System.out.println("| " + sumasFilas[i]);
        }
        
        for (int j = 0; j < sumasColumnas.length; j++) {
            System.out.print("--\t");
        }
        System.out.println("|");
        for (int j = 0; j < sumasColumnas.length; j++) {
            System.out.print(sumasColumnas[j] + "\t");
        }
        System.out.println("| " + sumaTotal);
    }
}

