/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio5 {
     public static void main(String[] args){
     Scanner sc = new Scanner (System.in);
    float num1,pow,resultado = 0;
    System.out.println("Numero: ");
    num1= sc.nextFloat(); 
    System.out.println("Elevado a: ");
    pow= sc.nextFloat();  
    
    if(pow==0){
        System.out.println("Su potencia es 1");
    }else if(pow < 0){
        pow=-pow;
          resultado = (float) (1 / Math.pow(num1, pow));
        System.out.println("El resultado es: " + resultado);   
    }else if (pow>0){
        resultado =(float) Math.pow(num1, pow);
        System.out.println("El resultado es: " + resultado);
    }
            
    
     }
         
}
