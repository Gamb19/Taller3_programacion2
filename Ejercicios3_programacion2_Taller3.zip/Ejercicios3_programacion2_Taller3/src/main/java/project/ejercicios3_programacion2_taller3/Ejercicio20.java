/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio20 {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.println("Numero 1: ");
        int num1= sc.nextInt();
        System.out.println("Numero 2: ");
        int num2=sc.nextInt();
        
        for(int i=num1;i<num2;i++){
            if(i%2==0){
                System.out.println("Numeros pares: "+ (i));
            }
        }
        
        
    }
}
