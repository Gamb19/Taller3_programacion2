/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio9 {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int annio;
        System.out.println("Digame el annio");
        annio=sc.nextInt();
        if(annio%4==0){
            System.out.println("Bisiesto");
        }else{
            System.out.print("No es");
        }
        
    }
}
