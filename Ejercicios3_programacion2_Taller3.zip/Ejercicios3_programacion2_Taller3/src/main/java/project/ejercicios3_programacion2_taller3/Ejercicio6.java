/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio6 {
 public static void main(String[] args){
     Scanner sc = new Scanner(System.in);
     String sexo;
     int nota,edad;
     
     System.out.println("Sexo: m o f");
     sexo=sc.nextLine();
     System.out.println("Nota");
     nota= sc.nextInt();
     System.out.println("Edad :");
     edad= sc.nextInt();
     
     if(nota==5 && edad==18 && sexo.equals("m")  ){
         System.out.println("Posible entrada");
     }else if(nota==5 && edad==18 && sexo.equals("f")){
         System.out.print("Aceptada");
     }else{
         System.out.println("No aceptada");
     }
     
 }   
}
