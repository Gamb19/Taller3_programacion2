/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;

/**
 *
 * @author molin
 */
public class Ejercicio12 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        float duracionllamada;
        String dia, turno;
        float total=0,impuesto=0,impuestoTurno=0;
        System.out.println("Cuanto duro su llamada en minutos: ");
        duracionllamada= sc.nextFloat();
        sc.nextLine();
        System.out.println("Que dia realizo la llamada: ");
        dia=sc.nextLine().toLowerCase();
        System.out.println("En que turno realizo la llamada (M o T): ");
        turno=sc.nextLine();
        
        
        if(duracionllamada<5){
        total=1;
        }else if(duracionllamada<=8){
        total=(float) (1+ 0.8)* (duracionllamada-5);
        }else if(duracionllamada <=10){
        total= (float) ((1+0.8+0.70)*(duracionllamada-8)); 
        }else{
        total= (float) ((1+0.8+0.70+0.50)*(duracionllamada-8)); 
        }
        
        if(dia.equals("domingo")){
         impuesto= (float) (total*0.03);   
         total=total+impuesto;
        }
        if(turno.equals("M")){
            impuestoTurno= (float) (total*0.15);
            total=total+impuestoTurno;
        }
        else if(turno.equals("T")){
            impuestoTurno= (float) (total*0.10);
            total=total+impuestoTurno;
        }
       System.out.println("La duracion de la llamada fue de: "+ duracionllamada);
       System.out.println("Se le cargaron un total de impuestos de: "+ (impuestoTurno+impuesto));
       System.out.println("El total de la llamada fue: "+total);
    }
}
