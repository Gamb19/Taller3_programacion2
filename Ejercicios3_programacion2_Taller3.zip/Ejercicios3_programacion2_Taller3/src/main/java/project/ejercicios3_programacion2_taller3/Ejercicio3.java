/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio3 {
     public static void main(String[] args){
     Scanner sc = new Scanner (System.in);
    float num1,num2,div;
    System.out.println("Numero 1:");
    num1= sc.nextFloat(); 
    System.out.println("Numero 2:");
    num2= sc.nextFloat();   
    
    if(num2==0){
        System.out.println("Es un error, daria infinito");
    }else{
        div= num1/num2;
        System.out.println("El total de tu division es: "+ div);
    }
    
     }
}
