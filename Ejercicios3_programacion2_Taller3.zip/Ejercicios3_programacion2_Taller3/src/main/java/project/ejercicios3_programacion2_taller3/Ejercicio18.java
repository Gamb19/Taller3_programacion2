/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio18 {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        float numero=0;
        int mayor=0,menor=0,igual=0;
        System.out.println("Cuantos numeros quiere ingresar: ");
        int cantidad= sc.nextInt();
        for(int i=0; i<cantidad; i++){
            System.out.println("Numero: ");
            numero=sc.nextFloat();
            if(numero>0){
                mayor++;
            }else if(numero<0){
                menor++;
            }else if(numero==0){
                igual++;
            }
        }
        System.out.println("Hubieron: \n"+ "Numeros mayores: "+mayor+"\n Numeros menores: "+menor+"\n Numeros iguales a 0:"+igual);
    }
}
