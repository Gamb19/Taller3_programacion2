/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;

import java.util.Scanner;

/**
 *
 * @author molin
 */
public class Ejercicio26 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el número de filas de la pirámide: ");
        int n = sc.nextInt();

        for (int i = 1; i <= n; i++) {
            // Imprime los espacios en blanco necesarios para centrar los números
            for (int j = 1; j <= n - i; j++) {
                System.out.print("  ");
            }

            // Imprime los números en orden creciente
            for (int j = 1; j <= i; j++) {
                System.out.printf("%2d", j);
            }

            // Imprime los números en orden decreciente
            for (int j = i - 1; j >= 1; j--) {
                System.out.printf("%2d", j);
            }

            System.out.println();
        }    
        
    }
}
