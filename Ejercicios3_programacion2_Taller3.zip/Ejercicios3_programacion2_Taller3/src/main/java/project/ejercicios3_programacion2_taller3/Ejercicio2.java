/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project.ejercicios3_programacion2_taller3;
import java.util.*;
/**
 *
 * @author molin
 */
public class Ejercicio2 {
    public static void main(String[] args){
     Scanner sc = new Scanner (System.in);
    float num1,validacion;
    System.out.println("Numero: ");
    num1= sc.nextFloat(); 
    validacion = num1 %2;
    if(validacion==0){
        System.out.println("Es par");
    } else{
        System.out.println("Es impar");
    }
    }
}
